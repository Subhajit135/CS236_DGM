#!/usr/bin/env bash
zip -r hw1.zip answers.pkl samples.txt shakespeare.png random.png nips.png shakespeare_raw.pkl random_raw.pkl nips_raw.pkl main.py model.py
